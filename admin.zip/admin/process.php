<?php
include 'connect.php';

	$id =  $_POST['id'];
	$nama =  $_POST['nama'];
	$ukuran =  $_POST['ukuran'];
	$jenis =  $_POST['jenis'];
	$lengan =  $_POST['lengan'];
	$stok =  $_POST['stok'];
	$design_kaos =  $_POST['design_kaos'];
	$harga =  $_POST['harga'];
	$status =  $_POST['status'];
	$diskon =  $_POST['diskon'];
	

	$sql= "INSERT INTO kaos VALUES('$id','$nama','$ukuran','$jenis','$lengan','$stok','$design_kaos','$harga','$status','$diskon')";

	if ($conn->query($sql) === TRUE) {
			header("location:tambah.php");
	} else {
	  # code...
	  echo "Error: " . $sql . "<br>" .$conn->error;

	}

?>
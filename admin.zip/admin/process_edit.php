<?php
include 'connect.php';

	$id =  $_POST['id'];
	$nama =  $_POST['nama'];
	$ukuran =  $_POST['ukuran'];
	$jenis =  $_POST['jenis'];
	$lengan =  $_POST['lengan'];
	$stok =  $_POST['stok'];
	$design_kaos =  $_POST['design_kaos'];
	$harga =  $_POST['harga'];
	$status =  $_POST['status'];
	$diskon =  $_POST['diskon'];
	

	$upt= "UPDATE kaos SET id='$id', nama='$nama', ukuran='$ukuran', jenis='$jenis', lengan='$lengan', stok='$stok', design_kaos='$design_kaos',
		harga='$harga', status='$status', diskon='$diskon' WHERE id='$id'";
	
		if ($conn->query($upt) === TRUE) {
			header("location:daftar_barang.php");
		} else {
		  # code...
		  echo "Error: " . $upt . "<br>" .$conn->error;

		}

?>
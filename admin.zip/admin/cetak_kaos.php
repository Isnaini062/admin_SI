<?php
include "connect.php";
require('fpdf17/fpdf.php');

error_reporting(E_ALL ^ E_DEPRECATED);
$result=mysqli_query($conn, "SELECT * FROM kaos");


//Inisiasi untuk membuat header kolom
$column_id = "";
$column_nama = "";
$column_ukuran = "";
$column_jenis = "";
$column_lengan = "";
$column_stok = "";
$column_harga = "";


//For each row, add the field to the corresponding column
while($row = mysqli_fetch_array($result))
{
	$id = $row["id"];
    $nama = $row["nama"];
    $ukuran = $row["ukuran"];
    $jenis = $row["jenis"];
    $lengan = $row["lengan"];
	$stok = $row["stok"];
	$harga = $row["harga"];
 
    

	$column_id = $column_id.$id."\n";
    $column_nama = $column_nama.$nama."\n";
    $column_ukuran = $column_ukuran.$ukuran."\n";
    $column_jenis = $column_jenis.$jenis."\n";
    $column_lengan = $column_lengan.$lengan."\n";
    $column_stok = $column_stok.$stok."\n";
	$column_harga = $column_harga.$harga."\n";
    

//Create a new PDF file
$pdf = new FPDF('P','mm',array(210,297)); //L For Landscape / P For Portrait
$pdf->AddPage();

//Menambahkan Gambar
//$pdf->Image('../foto/logo.png',10,10,-175);

$pdf->SetFont('Arial','B',13);
$pdf->Cell(80);
$pdf->Cell(30,10,'DATA PRODUK',0,0,'C');
$pdf->Ln();
$pdf->Cell(80);
$pdf->Cell(30,10,'Busantshirt Inc.',0,0,'C');
$pdf->Ln();

}
//Fields Name position
$Y_Fields_Name_position = 30;

//First create each Field Name
//Gray color filling each Field Name box

$pdf->SetFillColor(110,180,230);

//Bold Font for Field Name
$pdf->SetFont('Arial','B',10);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(5);
$pdf->Cell(20,8,'ID',1,0,'C',1);
$pdf->SetX(25);
$pdf->Cell(40,8,'Nama',1,0,'C',1);
$pdf->SetX(65);
$pdf->Cell(20,8,'Ukuran',1,0,'C',1);
$pdf->SetX(85);
$pdf->Cell(30,8,'Jenis',1,0,'C',1);
$pdf->SetX(115);
$pdf->Cell(30,8,'Lengan',1,0,'C',1);
$pdf->SetX(145);
$pdf->Cell(30,8,'Stok',1,0,'C',1);
$pdf->SetX(175);
$pdf->Cell(30,8,'Harga',1,0,'C',1);
$pdf->Ln();

//Table position, under Fields Name
$Y_Table_Position = 38;

//Now show the columns
$pdf->SetFont('Arial','',10);

$pdf->SetY($Y_Table_Position);
$pdf->SetX(5);
$pdf->MultiCell(20,6,$column_id,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(25);
$pdf->MultiCell(40,6,$column_nama,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(65);
$pdf->MultiCell(20,6,$column_ukuran,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(85);
$pdf->MultiCell(30,6,$column_jenis,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(115);
$pdf->MultiCell(30,6,$column_lengan,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(145);
$pdf->MultiCell(30,6,$column_stok,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(175);
$pdf->MultiCell(30,6,$column_harga,1,'C');

$pdf->Output();
?>

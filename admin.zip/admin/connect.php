<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "busanshirt";

//bikin koneksi
	$conn = new mysqli($servername, $username, $password, $dbname);
//cek koneksi
	if ($conn->connect_error) {
	  # code...
	  die("Connection failed: " . $conn->connect_error);
	}
?>